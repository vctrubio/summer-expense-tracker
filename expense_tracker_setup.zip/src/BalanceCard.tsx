interface BalanceCardProps {
  data: {
    totalExpenses: number;
    totalDeposits: number;
  };
}

export default function BalanceCard({ data }: BalanceCardProps) {
  const balance = data.totalDeposits - data.totalExpenses;
  const isPositive = balance >= 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="text-xs font-medium text-gray-600 mb-1">Balance</div>
        <div className={`text-xl font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? '+' : ''}${balance.toFixed(2)}
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="text-xs font-medium text-gray-600 mb-1">Deposits</div>
        <div className="text-xl font-bold text-green-600">
          +${data.totalDeposits.toFixed(2)}
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="text-xs font-medium text-gray-600 mb-1">Expenses</div>
        <div className="text-xl font-bold text-red-600">
          -${data.totalExpenses.toFixed(2)}
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="text-xs font-medium text-gray-600 mb-1">Net</div>
        <div className={`text-xl font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? '+' : ''}${balance.toFixed(2)}
        </div>
      </div>
    </div>
  );
}
