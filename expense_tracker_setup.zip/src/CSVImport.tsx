import { useState, useRef } from "react";
import { useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

interface CSVImportProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CSVRow {
  date: string;
  amount: string;
  description: string;
  category: string;
  name: string;
  type: 'expense' | 'deposit';
}

export default function CSVImport({ isOpen, onClose }: CSVImportProps) {
  const [csvData, setCsvData] = useState<CSVRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addExpense = useMutation(api.expenses.addExpense);
  const addDeposit = useMutation(api.expenses.addDeposit);
  const addLabel = useMutation(api.labels.add);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').filter(line => line.trim());
      
      const rows: CSVRow[] = lines.map(line => {
        const columns = line.split(',').map(col => col.replace(/"/g, '').trim());
        return {
          date: columns[0] || '',
          amount: columns[1] || '',
          description: columns[2] || '',
          category: columns[3] || '',
          name: columns[4] || '',
          type: 'expense' // default to expense
        };
      });

      setCsvData(rows);
    };
    reader.readAsText(file);
  };

  const handleTypeChange = (index: number, type: 'expense' | 'deposit') => {
    setCsvData(prev => prev.map((row, i) => 
      i === index ? { ...row, type } : row
    ));
  };

  const handleImport = async () => {
    if (csvData.length === 0) {
      toast.error("No data to import");
      return;
    }

    setIsProcessing(true);
    let successCount = 0;
    let errorCount = 0;

    try {
      for (const row of csvData) {
        try {
          const amount = parseFloat(row.amount);
          if (isNaN(amount) || !row.description.trim()) {
            errorCount++;
            continue;
          }

          const timestamp = row.date ? new Date(row.date).getTime() : Date.now();
          const label = row.category.trim() || 'General';
          
          // Add label if it doesn't exist (will handle duplicates in backend)
          if (label !== 'General') {
            try {
              await addLabel({ name: label });
            } catch (error) {
              // Label might already exist, continue
            }
          }

          const transactionData = {
            amount,
            desc: row.description.trim(),
            label,
            timestamp: isNaN(timestamp) ? Date.now() : timestamp,
          };

          if (row.type === 'expense') {
            await addExpense({
              ...transactionData,
              dst: row.name.trim() || undefined,
            });
          } else {
            await addDeposit({
              ...transactionData,
              by: row.name.trim() || undefined,
            });
          }

          successCount++;
        } catch (error) {
          errorCount++;
          console.error('Error importing row:', error);
        }
      }

      if (successCount > 0) {
        toast.success(`Successfully imported ${successCount} transactions`);
      }
      if (errorCount > 0) {
        toast.error(`Failed to import ${errorCount} transactions`);
      }

      // Reset form
      setCsvData([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      onClose();
    } catch (error) {
      toast.error("Import failed");
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-gray-800">Import CSV</h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600"
        >
          ×
        </button>
      </div>

      <div className="space-y-4">
        {/* File Upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Upload CSV File
          </label>
          <div className="text-xs text-gray-500 mb-2">
            Expected format: Date, Amount, Description, Category, Name (optional)
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
          />
        </div>

        {/* Preview Data */}
        {csvData.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium text-gray-800">Preview & Configure ({csvData.length} rows)</h4>
            <div className="max-h-60 overflow-y-auto border border-gray-200 rounded">
              <table className="w-full text-xs">
                <thead className="bg-gray-50 sticky top-0">
                  <tr>
                    <th className="px-2 py-1 text-left">Date</th>
                    <th className="px-2 py-1 text-left">Amount</th>
                    <th className="px-2 py-1 text-left">Description</th>
                    <th className="px-2 py-1 text-left">Category</th>
                    <th className="px-2 py-1 text-left">Name</th>
                    <th className="px-2 py-1 text-left">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {csvData.map((row, index) => (
                    <tr key={index} className="border-t border-gray-100">
                      <td className="px-2 py-1">{row.date}</td>
                      <td className="px-2 py-1">{row.amount}</td>
                      <td className="px-2 py-1 truncate max-w-24">{row.description}</td>
                      <td className="px-2 py-1">{row.category}</td>
                      <td className="px-2 py-1">{row.name}</td>
                      <td className="px-2 py-1">
                        <select
                          value={row.type}
                          onChange={(e) => handleTypeChange(index, e.target.value as 'expense' | 'deposit')}
                          className="text-xs border border-gray-300 rounded px-1 py-0.5"
                        >
                          <option value="expense">Expense</option>
                          <option value="deposit">Deposit</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded text-sm hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          {csvData.length > 0 && (
            <button
              onClick={handleImport}
              disabled={isProcessing}
              className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isProcessing ? 'Importing...' : `Import ${csvData.length} Transactions`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
