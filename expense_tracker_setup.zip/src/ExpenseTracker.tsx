import { useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import TransactionForm from "./TransactionForm";
import TransactionList from "./TransactionList";
import DateFilter from "./DateFilter";
import BalanceCard from "./BalanceCard";
import ManageLabelsOwners from "./ManageLabelsOwners";
import CSVImport from "./CSVImport";
import HotkeyInfo from "./HotkeyInfo";

export default function ExpenseTracker() {
  const [dateRange, setDateRange] = useState<{ start: number; end: number } | null>(null);
  const [activeForm, setActiveForm] = useState<'expense' | 'deposit' | 'manage' | 'csv' | null>(null);
  const [showHotkeys, setShowHotkeys] = useState(false);

  const data = useQuery(api.expenses.list, dateRange ? {
    startDate: dateRange.start,
    endDate: dateRange.end,
  } : {});

  const dateRangeData = useQuery(api.expenses.getDateRange);

  // Global hotkeys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
        return;
      }

      switch (e.key.toLowerCase()) {
        case 'e':
          e.preventDefault();
          setActiveForm(activeForm === 'expense' ? null : 'expense');
          break;
        case 'd':
          e.preventDefault();
          setActiveForm(activeForm === 'deposit' ? null : 'deposit');
          break;
        case 'm':
          e.preventDefault();
          setActiveForm(activeForm === 'manage' ? null : 'manage');
          break;
        case 'c':
          e.preventDefault();
          setActiveForm(activeForm === 'csv' ? null : 'csv');
          break;
        case 'escape':
          e.preventDefault();
          setActiveForm(null);
          break;
        case '?':
          e.preventDefault();
          setShowHotkeys(!showHotkeys);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeForm, showHotkeys]);

  const hasTransactions = data && (data.expenses.length > 0 || data.deposits.length > 0);

  if (data === undefined || dateRangeData === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-600"></div>
      </div>
    );
  }

  if (!hasTransactions && !dateRange) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="text-center py-16">
          <div className="text-4xl mb-4">💰</div>
          <h2 className="text-xl font-medium text-gray-800 mb-2">No transactions yet</h2>
          <p className="text-gray-600 mb-8">
            Press <kbd className="px-2 py-1 bg-gray-100 rounded text-sm">E</kbd> for expense, 
            <kbd className="px-2 py-1 bg-gray-100 rounded text-sm ml-1">D</kbd> for deposit, 
            <kbd className="px-2 py-1 bg-gray-100 rounded text-sm ml-1">C</kbd> for CSV import, or 
            <kbd className="px-2 py-1 bg-gray-100 rounded text-sm ml-1">?</kbd> for help
          </p>
        </div>

        <TransactionForm
          type="expense"
          isOpen={activeForm === 'expense'}
          onClose={() => setActiveForm(null)}
        />

        <TransactionForm
          type="deposit"
          isOpen={activeForm === 'deposit'}
          onClose={() => setActiveForm(null)}
        />

        <ManageLabelsOwners
          isOpen={activeForm === 'manage'}
          onClose={() => setActiveForm(null)}
        />

        <CSVImport
          isOpen={activeForm === 'csv'}
          onClose={() => setActiveForm(null)}
        />

        <HotkeyInfo isOpen={showHotkeys} onClose={() => setShowHotkeys(false)} />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Quick Actions Bar */}
      <div className="flex items-center justify-between py-2 border-b border-gray-200">
        <div className="flex items-center gap-4 text-sm text-gray-600">
          <button
            onClick={() => setActiveForm(activeForm === 'expense' ? null : 'expense')}
            className={`px-3 py-1 rounded transition-colors ${
              activeForm === 'expense' ? 'bg-red-100 text-red-700' : 'hover:bg-gray-100'
            }`}
          >
            <kbd className="mr-1">E</kbd> Expense
          </button>
          <button
            onClick={() => setActiveForm(activeForm === 'deposit' ? null : 'deposit')}
            className={`px-3 py-1 rounded transition-colors ${
              activeForm === 'deposit' ? 'bg-green-100 text-green-700' : 'hover:bg-gray-100'
            }`}
          >
            <kbd className="mr-1">D</kbd> Deposit
          </button>
          <button
            onClick={() => setActiveForm(activeForm === 'csv' ? null : 'csv')}
            className={`px-3 py-1 rounded transition-colors ${
              activeForm === 'csv' ? 'bg-purple-100 text-purple-700' : 'hover:bg-gray-100'
            }`}
          >
            <kbd className="mr-1">C</kbd> Import CSV
          </button>
          <button
            onClick={() => setActiveForm(activeForm === 'manage' ? null : 'manage')}
            className={`px-3 py-1 rounded transition-colors ${
              activeForm === 'manage' ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'
            }`}
          >
            <kbd className="mr-1">M</kbd> Manage
          </button>
        </div>
        <button
          onClick={() => setShowHotkeys(!showHotkeys)}
          className="text-gray-500 hover:text-gray-700 text-sm"
        >
          <kbd>?</kbd> Help
        </button>
      </div>

      {/* Inline Forms */}
      <TransactionForm
        type="expense"
        isOpen={activeForm === 'expense'}
        onClose={() => setActiveForm(null)}
      />

      <TransactionForm
        type="deposit"
        isOpen={activeForm === 'deposit'}
        onClose={() => setActiveForm(null)}
      />

      <CSVImport
        isOpen={activeForm === 'csv'}
        onClose={() => setActiveForm(null)}
      />

      <ManageLabelsOwners
        isOpen={activeForm === 'manage'}
        onClose={() => setActiveForm(null)}
      />

      {/* Balance Overview */}
      <BalanceCard data={data} />

      {/* Date Filter */}
      <DateFilter
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
        availableRange={dateRangeData}
      />

      {/* Transaction List */}
      <TransactionList data={data} />

      {/* Hotkey Help */}
      <HotkeyInfo isOpen={showHotkeys} onClose={() => setShowHotkeys(false)} />
    </div>
  );
}
