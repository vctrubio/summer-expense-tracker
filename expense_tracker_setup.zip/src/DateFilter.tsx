import { useState } from "react";

interface DateFilterProps {
  dateRange: { start: number; end: number } | null;
  onDateRangeChange: (range: { start: number; end: number } | null) => void;
  availableRange: { earliest: number; latest: number } | null;
}

export default function DateFilter({ dateRange, onDateRangeChange, availableRange }: DateFilterProps) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const formatDateForInput = (timestamp: number) => {
    return new Date(timestamp).toISOString().split('T')[0];
  };

  const handleApplyFilter = () => {
    if (startDate && endDate) {
      const start = new Date(startDate).getTime();
      const end = new Date(endDate + 'T23:59:59').getTime();
      onDateRangeChange({ start, end });
    }
  };

  const handleClearFilter = () => {
    setStartDate('');
    setEndDate('');
    onDateRangeChange(null);
  };

  const setQuickRange = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - days);
    
    setStartDate(formatDateForInput(start.getTime()));
    setEndDate(formatDateForInput(end.getTime()));
    
    onDateRangeChange({
      start: start.getTime(),
      end: end.getTime()
    });
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4">
      <div className="flex flex-wrap gap-3 items-end">
        <div className="flex gap-2">
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
            min={availableRange ? formatDateForInput(availableRange.earliest) : undefined}
            max={availableRange ? formatDateForInput(availableRange.latest) : undefined}
          />
          <span className="text-gray-500 self-center">to</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
            min={availableRange ? formatDateForInput(availableRange.earliest) : undefined}
            max={availableRange ? formatDateForInput(availableRange.latest) : undefined}
          />
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={handleApplyFilter}
            disabled={!startDate || !endDate}
            className="px-3 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Apply
          </button>
          <button
            onClick={handleClearFilter}
            className="px-3 py-2 border border-gray-300 text-gray-700 rounded text-sm hover:bg-gray-50 transition-colors"
          >
            Clear
          </button>
        </div>
      </div>
      
      <div className="mt-3 flex flex-wrap gap-2">
        <span className="text-xs text-gray-600 self-center">Quick:</span>
        <button
          onClick={() => setQuickRange(7)}
          className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded hover:bg-gray-200 transition-colors"
        >
          7d
        </button>
        <button
          onClick={() => setQuickRange(30)}
          className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded hover:bg-gray-200 transition-colors"
        >
          30d
        </button>
        <button
          onClick={() => setQuickRange(90)}
          className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded hover:bg-gray-200 transition-colors"
        >
          90d
        </button>
      </div>
      
      {dateRange && (
        <div className="mt-2 text-xs text-gray-600">
          {new Date(dateRange.start).toLocaleDateString()} - {new Date(dateRange.end).toLocaleDateString()}
        </div>
      )}
    </div>
  );
}
