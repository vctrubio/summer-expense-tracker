import { useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

interface Transaction {
  _id: Id<"expenses"> | Id<"deposits">;
  timestamp: number;
  amount: number;
  desc: string;
  label: string;
  dst?: string;
  by?: string;
}

interface TransactionListProps {
  data: {
    expenses: Array<Transaction & { _id: Id<"expenses"> }>;
    deposits: Array<Transaction & { _id: Id<"deposits"> }>;
    totalExpenses: number;
    totalDeposits: number;
  };
}

export default function TransactionList({ data }: TransactionListProps) {
  const deleteExpense = useMutation(api.expenses.deleteExpense);
  const deleteDeposit = useMutation(api.expenses.deleteDeposit);

  // Combine and sort transactions by timestamp
  const allTransactions = [
    ...data.expenses.map(exp => ({ ...exp, type: 'expense' as const })),
    ...data.deposits.map(dep => ({ ...dep, type: 'deposit' as const }))
  ].sort((a, b) => b.timestamp - a.timestamp);

  const handleDelete = async (transaction: typeof allTransactions[0]) => {
    try {
      if (transaction.type === 'expense') {
        await deleteExpense({ id: transaction._id as Id<"expenses"> });
      } else {
        await deleteDeposit({ id: transaction._id as Id<"deposits"> });
      }
      toast.success(`${transaction.type} deleted`);
    } catch (error) {
      toast.error(`Failed to delete ${transaction.type}`);
    }
  };

  const exportToCSV = () => {
    const headers = ['Date', 'Type', 'Amount', 'Description', 'Label', 'Owner'];
    const rows = allTransactions.map(t => [
      new Date(t.timestamp).toLocaleDateString(),
      t.type,
      t.amount.toFixed(2),
      t.desc,
      t.label,
      t.type === 'expense' ? (t.dst || '') : (t.by || '')
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transactions-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (allTransactions.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <div className="text-2xl mb-2">📄</div>
        <p className="text-sm">No transactions found</p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-200 flex justify-between items-center">
        <h3 className="font-medium text-gray-800">Transactions ({allTransactions.length})</h3>
        <button
          onClick={exportToCSV}
          className="text-sm text-blue-600 hover:text-blue-700 underline"
        >
          Export CSV
        </button>
      </div>
      
      <div className="divide-y divide-gray-100">
        {allTransactions.map((transaction) => (
          <div key={transaction._id} className="px-4 py-3 hover:bg-gray-50 group">
            <div className="flex justify-between items-start">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                    transaction.type === 'expense'
                      ? 'bg-red-50 text-red-700'
                      : 'bg-green-50 text-green-700'
                  }`}>
                    {transaction.type === 'expense' ? '−' : '+'} ${transaction.amount.toFixed(2)}
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(transaction.timestamp).toLocaleDateString()}
                  </span>
                </div>
                
                <p className="font-medium text-gray-900 text-sm mb-1 truncate">{transaction.desc}</p>
                
                <div className="flex gap-3 text-xs text-gray-600">
                  <span>{transaction.label}</span>
                  {((transaction.type === 'expense' && transaction.dst) || 
                    (transaction.type === 'deposit' && transaction.by)) && (
                    <span>
                      {transaction.type === 'expense' ? '→' : '←'} {
                        transaction.type === 'expense' ? transaction.dst : transaction.by
                      }
                    </span>
                  )}
                </div>
              </div>
              
              <button
                onClick={() => handleDelete(transaction)}
                className="opacity-0 group-hover:opacity-100 text-red-600 hover:text-red-800 text-xs px-2 py-1 rounded hover:bg-red-50 transition-all"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
