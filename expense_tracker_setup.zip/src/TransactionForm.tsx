import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

interface TransactionFormProps {
  type: 'expense' | 'deposit';
  isOpen: boolean;
  onClose: () => void;
}

export default function TransactionForm({ type, isOpen, onClose }: TransactionFormProps) {
  const [amount, setAmount] = useState('');
  const [desc, setDesc] = useState('');
  const [label, setLabel] = useState('');
  const [owner, setOwner] = useState('');
  const [customLabel, setCustomLabel] = useState('');
  const [customOwner, setCustomOwner] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const amountRef = useRef<HTMLInputElement>(null);

  const labels = useQuery(api.labels.list) || [];
  const owners = useQuery(api.owners.list) || [];
  
  const addExpense = useMutation(api.expenses.addExpense);
  const addDeposit = useMutation(api.expenses.addDeposit);
  const addLabel = useMutation(api.labels.add);
  const addOwner = useMutation(api.owners.add);

  // Focus on amount input when form opens
  useEffect(() => {
    if (isOpen && amountRef.current) {
      amountRef.current.focus();
    }
  }, [isOpen]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if ((e.key === 'Enter' && (e.shiftKey || e.metaKey || e.ctrlKey))) {
        e.preventDefault();
        handleSubmit(e as any);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !desc) {
      toast.error("Amount and description are required");
      return;
    }

    setIsSubmitting(true);
    try {
      let finalLabel = label;
      let finalOwner = owner;

      // Add custom label if provided
      if (customLabel && !label) {
        await addLabel({ name: customLabel });
        finalLabel = customLabel;
      }

      // Add custom owner if provided
      if (customOwner && !owner) {
        await addOwner({ name: customOwner });
        finalOwner = customOwner;
      }

      const transactionData = {
        amount: parseFloat(amount),
        desc,
        label: finalLabel || 'General',
      };

      if (type === 'expense') {
        await addExpense({
          ...transactionData,
          dst: finalOwner || undefined,
        });
        toast.success("Expense added");
      } else {
        await addDeposit({
          ...transactionData,
          by: finalOwner || undefined,
        });
        toast.success("Deposit added");
      }

      // Reset form
      setAmount('');
      setDesc('');
      setLabel('');
      setOwner('');
      setCustomLabel('');
      setCustomOwner('');
      onClose();
    } catch (error) {
      toast.error("Failed to add transaction");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-gray-800">
          Add {type === 'expense' ? 'Expense' : 'Deposit'}
        </h3>
        <div className="text-xs text-gray-500">
          <kbd className="px-1 py-0.5 bg-gray-100 rounded">Shift+Enter</kbd> to submit, <kbd className="px-1 py-0.5 bg-gray-100 rounded">Esc</kbd> to close
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <div>
          <input
            ref={amountRef}
            type="number"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="Amount"
            required
          />
        </div>

        <div>
          <input
            type="text"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="Description"
            required
          />
        </div>

        <div>
          <select
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
          >
            <option value="">Label</option>
            {labels.map((l) => (
              <option key={l._id} value={l.name}>
                {l.name}
              </option>
            ))}
          </select>
          {!label && (
            <input
              type="text"
              value={customLabel}
              onChange={(e) => setCustomLabel(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm mt-1"
              placeholder="New label"
            />
          )}
        </div>

        <div>
          <select
            value={owner}
            onChange={(e) => setOwner(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
          >
            <option value="">{type === 'expense' ? 'To' : 'By'}</option>
            {owners.map((o) => (
              <option key={o._id} value={o.name}>
                {o.name}
              </option>
            ))}
          </select>
          {!owner && (
            <input
              type="text"
              value={customOwner}
              onChange={(e) => setCustomOwner(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm mt-1"
              placeholder="New owner"
            />
          )}
        </div>

        <div className="flex gap-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`px-4 py-2 text-white rounded text-sm font-medium transition-colors disabled:opacity-50 ${
              type === 'expense'
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isSubmitting ? '...' : 'Add'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded text-sm hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
